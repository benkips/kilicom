package com.mabnets.kilicom;

import java.io.Serializable;

public class subdata implements Serializable {
    public String month;
    public  String amount;
}
