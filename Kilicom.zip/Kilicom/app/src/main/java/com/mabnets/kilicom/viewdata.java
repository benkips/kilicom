package com.mabnets.kilicom;

import java.io.Serializable;

public class viewdata implements Serializable {
    public String photo;
    public String product;
    public String  price;
    public String location;
    public String details;
}
