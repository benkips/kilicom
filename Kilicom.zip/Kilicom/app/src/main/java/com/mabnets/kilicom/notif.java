package com.mabnets.kilicom;

import java.io.Serializable;

public class notif implements Serializable {
    public String phone;
    public String status;
    public String type;
    public String title;
    public String message;
    public  String time;
}
