package com.mabnets.kilicom;

import java.io.Serializable;

public class total implements Serializable {
    public  String subcategory;
    public  String totalproducts;
    public  String photo;
    public  String market;
    public  String county;
    public  String total;

}
