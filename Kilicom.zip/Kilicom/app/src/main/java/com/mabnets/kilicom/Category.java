package com.mabnets.kilicom;

import java.io.Serializable;

public class Category implements Serializable {
    public  String category;
    public  String subcategory;
    public  String photo;
}
