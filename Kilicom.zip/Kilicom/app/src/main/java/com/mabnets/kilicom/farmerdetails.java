package com.mabnets.kilicom;
import java.io.Serializable;
public class farmerdetails implements Serializable {
    public String name;
    public String email;
    public String photo;
    public String location;
    public String bio;
    public String phone;
    public String contact;
}
