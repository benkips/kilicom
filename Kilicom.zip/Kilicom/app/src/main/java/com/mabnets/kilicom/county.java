package com.mabnets.kilicom;
import java.io.Serializable;

public class county implements Serializable{
    public String county;
    public String market;
}
