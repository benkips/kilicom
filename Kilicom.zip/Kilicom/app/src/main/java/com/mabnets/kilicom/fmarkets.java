package com.mabnets.kilicom;
import java.io.Serializable;
public class fmarkets implements Serializable {
    public String market;
    public String photo;
    public String details;
    public String county;



}
