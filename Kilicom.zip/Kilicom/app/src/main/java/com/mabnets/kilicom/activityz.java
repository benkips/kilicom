package com.mabnets.kilicom;

import java.io.Serializable;

public class activityz implements Serializable {
    public  String user;
    public  String crop;
    public  String photo;
    public  String details;
    public  String reply;
    public  String affected;

}
